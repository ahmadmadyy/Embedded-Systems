/*
* main.c
* Created: 9/23/2023 6:49:01 PM
*  Author: Hassan
*/

#define F_CPU  16000000UL
#include <util/delay.h>

#include "DIO_int.h"
/*
#define LED0_DDR  DDRC
#define LED0_PORT  PORTC
#define LED0_PIN 2

#define LED1_DDR  DDRC
#define LED1_PORT  PORTC
#define LED1_PIN 7

#define LED2_DDR  DDRD
#define LED2_PORT  PORTD
#define LED2_PIN     3*/

int main(void)
{

	while(1)
	{
		_delay_ms(250);
	}
}