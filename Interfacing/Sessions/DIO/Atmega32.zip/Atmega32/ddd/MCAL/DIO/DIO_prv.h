/*
 * DIO_prv.h
 *
 * Created: 9/23/2023 10:05:24 PM
 *  Author: Hassan
 */ 


#ifndef DIO_PRV_H_
#define DIO_PRV_H_


#endif /* DIO_PRV_H_ */