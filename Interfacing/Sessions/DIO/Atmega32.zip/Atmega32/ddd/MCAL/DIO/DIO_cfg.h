/*
 * DIO_cfg.h
 *
 * Created: 9/23/2023 10:05:04 PM
 *  Author: Hassan
 */ 


#ifndef DIO_CFG_H_
#define DIO_CFG_H_


typedef enum {DIO_PORTA, DIO_PORTB , DIO_PORTC ,DIO_PORTD}port_type;
typedef enum {P0,P1,P2,P3,P4,P5,P6,P7 } pin_type;



#endif /* DIO_CFG_H_ */