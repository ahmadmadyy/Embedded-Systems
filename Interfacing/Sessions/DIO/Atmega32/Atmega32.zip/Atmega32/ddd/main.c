#define F_CPU  16000000UL
#include <util/delay.h>

#include "DIO_int.h"

int main(void)
{
	//DIO_SetPinDir(DIO_PORTD,P3,OUTPUT);
	//DIO_SetPinDir(DIO_PORTC,P2,OUTPUT);
	//DIO_SetPinDir(DIO_PORTC,P7,OUTPUT);
	
	DIO_SetPinDir(DIO_PORTA,P4,OUTPUT);
	DIO_SetPinDir(DIO_PORTA,P5,OUTPUT);
	DIO_SetPinDir(DIO_PORTA,P6,OUTPUT);
	DIO_SetPinDir(DIO_PORTA,P7,OUTPUT);
	
	DIO_SetPinDir(DIO_PORTB,P0,INPUT);
	DIO_SetPinDir(DIO_PORTD,P6,INPUT);
	DIO_SetPinDir(DIO_PORTD,P2,INPUT);
	
	DIO_SetPinDir(DIO_PORTB,P1,OUTPUT);
	DIO_SetPinDir(DIO_PORTB,P2,OUTPUT);
	
	DIO_SetPinState(DIO_PORTB,P1,HIGH);
	DIO_SetPinState(DIO_PORTB,P2,HIGH);
	
	int ctr = 0;

	while(1)
	{
		
		//DIO_SetPinState(DIO_PORTD,P3,HIGH);
		//_delay_ms(250);
		//DIO_SetPinState(DIO_PORTC,P7,HIGH);
		//_delay_ms(250);
		//DIO_SetPinState(DIO_PORTC,P2,HIGH);
		//_delay_ms(250);
		//
		//DIO_SetPinState(DIO_PORTD,P3,LOW);
		//_delay_ms(250);
		//DIO_SetPinState(DIO_PORTC,P7,LOW);
		//_delay_ms(250);
		//DIO_SetPinState(DIO_PORTC,P2,LOW);
		//_delay_ms(250);
		
		//DIO_TogPinState(DIO_PORTD,P3);
		//_delay_ms(250);
		//DIO_TogPinState(DIO_PORTC,P7);
		//_delay_ms(250);
		//DIO_TogPinState(DIO_PORTC,P2);
		//_delay_ms(250);
		
		if(DIO_GetPinState(DIO_PORTB,P0) == HIGH)
		{
			_delay_ms(100);
			if(DIO_GetPinState(DIO_PORTB,P0) == HIGH)
			{
				ctr = 0;
			}
		}
		if(DIO_GetPinState(DIO_PORTD,P6) == HIGH)
		{
			_delay_ms(100);
			if(DIO_GetPinState(DIO_PORTD,P6) == HIGH)
			{
				ctr++;
			}
		}
		if(DIO_GetPinState(DIO_PORTD,P2) == HIGH)
		{
			_delay_ms(100);
			if(DIO_GetPinState(DIO_PORTD,P2) == HIGH)
			{
				ctr--;
			}
		}
		PORTA = (ctr<<4);
	}
}